# MAPPA on Overleaf

1. Choose New Project > Upload Project and upload this ZIP.
2. Set the main document to `preprint.tex`.
3. Select the XeLaTeX compiler, then Recompile.

The manuscript, supplement, bibliography, figures, class and custom font are
included. No Python processing or benchmark data is required to compile it.
