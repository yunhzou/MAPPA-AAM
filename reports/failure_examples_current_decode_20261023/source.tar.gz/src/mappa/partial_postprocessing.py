"""Reference-blind output selection for complete or partial saved mappings.

This is separate from the balanced signed-event decoder. Completeness means
exhaustion of the supplied saved path families, not full atom coverage or an
uncapped search. Selection uses Golden's coverage priority, then minimum+slack.
"""
from .family_scoring import bond_events
from .pattern_collection import PatternEquivalence, extract_path_patterns


def chemical_equivalence(problem, reaction):
    """Retain supplied charge, isotope and stereo labels on every atom/bond."""
    import ast
    import numpy as np
    from rdkit import Chem

    atom_tags, bond_tags = [], []
    for endpoint, smiles in zip((problem.reactant, problem.product), reaction.split('>>')):
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            raise ValueError('Invalid reaction endpoint')
        for atom in mol.GetAtoms():
            atom.SetAtomMapNum(0)
        Chem.MolToSmiles(mol, canonical=True)
        order = ast.literal_eval(mol.GetProp('_smilesAtomOutputOrder'))
        mol = Chem.AddHs(Chem.RenumberAtoms(mol, order))
        Chem.AssignStereochemistry(mol, cleanIt=True, force=True)
        assert tuple(a.GetSymbol() for a in mol.GetAtoms()) == tuple(endpoint.elements)
        matrix = np.zeros_like(endpoint.wbo)
        bonds = {}
        for bond in mol.GetBonds():
            a, b = bond.GetBeginAtomIdx(), bond.GetEndAtomIdx()
            matrix[a, b] = matrix[b, a] = bond.GetBondTypeAsDouble()
            bonds[tuple(sorted((a, b)))] = str(bond.GetStereo())
        assert np.array_equal(matrix, endpoint.wbo), 'Input atom ordering changed'
        atom_tags.append({a.GetIdx(): (a.GetFormalCharge(), a.GetIsotope(),
                          a.GetProp('_CIPCode') if a.HasProp('_CIPCode') else '')
                          for a in mol.GetAtoms()})
        bond_tags.append(bonds)
    assert len(atom_tags) == 2
    return PatternEquivalence(problem, atom_tags=atom_tags, bond_tags=bond_tags)


def describe_mapping(problem, mapping):
    mapping = dict(mapping)
    r, p = problem.reactant, problem.product
    assert len(set(mapping.values())) == len(mapping), 'Noninjective mapping'
    assert all(0 <= a < r.atom_count and 0 <= b < p.atom_count
               and r.elements[a] == p.elements[b] for a, b in mapping.items())
    heavy = sum(r.elements[a] != 'H' for a in mapping)
    return dict(mapping=sorted(mapping.items()), mapped_atoms=len(mapping),
                mapped_heavy_atoms=heavy,
                unmatched_reactant_atoms=sorted(set(range(r.atom_count))-set(mapping)),
                unmatched_product_atoms=sorted(set(range(p.atom_count))-set(mapping.values())),
                reactant_atoms=r.atom_count, product_atoms=p.atom_count,
                reactant_heavy_atoms=sum(e != 'H' for e in r.elements),
                product_heavy_atoms=sum(e != 'H' for e in p.elements),
                full_atom_bijection=len(mapping) == r.atom_count == p.atom_count)


class PartialOutputCollector:
    def __init__(self, problem, equivalence, event_slack=5):
        if event_slack < 0:
            raise ValueError('event_slack must be nonnegative')
        self.problem, self.equivalence = problem, equivalence
        self.event_slack = event_slack
        self.candidates, self.paths = {}, {}

    def add(self, path_id, report):
        assert path_id not in self.paths, 'Duplicate path identity'
        self.paths[path_id] = bool(report['complete'])
        for pattern in report['patterns']:
            mapping = dict(pattern['mapping'])
            record = describe_mapping(self.problem, mapping)
            events = bond_events(self.problem, mapping)
            assert events == pattern['events']
            key = self.equivalence.key(mapping)
            assert key == pattern['key']
            if key not in self.candidates:
                self.candidates[key] = dict(id=key, **record, events=events,
                    total=events['total'], witness_path=path_id)

    def result(self, *, all_cuts_visited):
        complete = bool(all_cuts_visited) and all(self.paths.values())
        candidates = list(self.candidates.values())
        coverage = max(((c['mapped_heavy_atoms'], c['mapped_atoms'])
                        for c in candidates), default=None)
        selected = [c for c in candidates
                    if (c['mapped_heavy_atoms'], c['mapped_atoms']) == coverage]
        minimum = min((c['total'] for c in selected), default=None)
        window = None if minimum is None else minimum+self.event_slack
        selected = [c for c in selected if c['total'] <= window]
        return dict(schema='mappa.partial_outputs/v1', complete=complete,
                    all_cuts_visited=bool(all_cuts_visited), paths=len(self.paths),
                    incomplete_paths=[k for k, v in self.paths.items() if not v],
                    decoded_class_count=len(candidates), best_coverage=coverage,
                    observed_minimum=minimum, minimum_proven=complete and minimum is not None,
                    event_window=window, event_slack=self.event_slack,
                    policy='maximum mapped heavy atoms, maximum mapped atoms, minimum+slack Golden bond events',
                    completeness_scope='All exact mapping classes in all supplied retained path families',
                    candidates=sorted(selected, key=lambda c: (c['total'], c['id'])))


def extract_partial_path(path, problem, equivalence, *, previous=(), seconds=600,
                         on_pattern=None):
    return extract_path_patterns(path, problem, equivalence, previous=previous,
                                 seconds=seconds, on_pattern=on_pattern)
